import { Component } from '@angular/core';
import { SocketioService } from './socketio.service';
import { MyserviceService} from './myservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'chat-bot';
  
  email:string;
  pw:string;
  loginData:any={};
  result: any;
  flag: boolean= false;
  constructor(private socketService: SocketioService , 
    private MyserviceService:MyserviceService,
    private router :Router) {}
  ngOnInit() {
    // this.socketService.setupSocketConnection();    
  }
  login(){
    this.loginData.email=this.email;
    this.loginData.pw=this.pw;
    this.MyserviceService.Login(this.loginData).subscribe(res=>{
      this.result=res;
      console.log(this.result);
      if(this.result.msg == "Login Succesfull"){
      // this.MyserviceService.getUsers(this.email).subscribe();
        localStorage.setItem('email',this.loginData.email );
        this.router.navigate(['/theme']);
      }
    });
    
}
 
}

