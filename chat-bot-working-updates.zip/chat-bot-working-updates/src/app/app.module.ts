import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {SocketioService} from './socketio.service';
import { LoginComponent } from './login/login.component';
import { RegistorComponent } from './registor/registor.component';
import { ThemeComponent } from './theme/theme.component';
import { FormsModule } from '@angular/forms';
import {MyserviceService} from './myservice.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistorComponent,
    ThemeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [SocketioService,MyserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
