import { Component, OnInit } from '@angular/core';
import {MyserviceService} from '../myservice.service';

@Component({
  selector: 'app-registor',
  templateUrl: './registor.component.html',
  styleUrls: ['./registor.component.css']
})
export class RegistorComponent implements OnInit {
  email:string;
  pw:string;
  na:string;
  uname:string;
  result:any
  registerData:any={};
  constructor(private MyserviceService: MyserviceService) { }

  ngOnInit(): void {
  }
  register(){
    this.registerData.email=this.email;
    this.registerData.pw=this.pw;
    this.registerData.na=this.na;
    this.registerData.uname=this.uname;
    console.log(this.email);
    console.log(this.pw);
    console.log(this.na);
    console.log(this.uname);
    this.MyserviceService.Register(this.registerData).subscribe(res=>{
      this.result=res;
      console.log(this.result);
    });

  }

}
