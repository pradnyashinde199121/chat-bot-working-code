import { Component, OnInit } from '@angular/core';
import { MyserviceService} from '../myservice.service';
import { SocketioService } from '../socketio.service';
import { from } from 'rxjs';
import { isNullOrUndefined } from 'util';
@Component({
  selector: 'app-theme',
  templateUrl: './theme.component.html',
  styleUrls: ['./theme.component.css']
})
export class ThemeComponent implements OnInit {
  userData:any;
  users:any;
  visitorInfo:any;
  currentChatName:any;
  currentImgUrl:any;
  isVisible : boolean = false;
  editable:boolean=false;
  chatbotResponse:any;
  sendMsg:any;
  msgSend: boolean;
  msgDataAdmin: any;
  sendMsgs:any=[];
  currentMsgs:any=[];
  historyMsgs:any=[];
  startChat:boolean=false;
  message:any = {};
  message1:any = {};
  claimObj:any = {};
  roomObj:any ={};
  isShowDiv=true;
  isShowDiv1=true;
  CurrentVisitorName: any;
  CurrentVisitorIP: any;
  CurrentVisitorLocation: any;
  CurrentVisitorBrowser: any;
  CurrentVisitorPCtype: any;
  CurrentVisitorAdded: any;
  CurrentVisitorOs: any;
  CurrentVisitorId: any;
  CurrentVisitorKey:any;
  agentInfo: any;
  email: any= localStorage.getItem('email');
  roomId: any;
  constructor(private MyserviceService: MyserviceService, private SocketioService:SocketioService) { }

  ngOnInit() {
    this.SocketioService.setupSocketConnection();
    this.SocketioService.getVisitorHistory();
    this.MyserviceService.getUser().subscribe(res => {
      this.users =res;
    // console.log(this.users);
    });
    // this.MyserviceService.getVisitor().subscribe(res=> {
    //   this.visitorInfo = res.chatsResult;
    //   this.agentInfo = res.visitorsResult;

    //   });
      //visitorInfo------------online users----APi chatsresultfield
    this.MyserviceService.getUsers().subscribe(res =>{
      this.userData =res;
      this.visitorInfo = res.chatsResult;
      this.agentInfo = res.visitorsResult;
      
      console.log(this.userData);
    });

     this.SocketioService.chatMsgs.subscribe(res=>{
      if(res!=null)
      {
        this.currentMsgs.push(res);
      }
     });
     this.SocketioService.historyMsgs.subscribe(res=>{
      if(res!=null)
      {
        this.historyMsgs=res;
        console.log(this.historyMsgs);
      }
     });
  
console.log("loaclStorage:"+ localStorage.getItem('email'));
    
    }

    getCurrentChat(user){
       this.currentChatName= user.name;
       this.currentImgUrl =user.url;
       this.currentMsgs=[];
       console.log(user);
    }
    claimedVisitor(visitor){
      this.claimObj.visitorId = visitor.id;
      this.claimObj.visitorName =visitor.visitorName;
      this.claimObj.agentId = this.userData.userId;
      this.claimObj.agentName = this.userData.user;
      this.claimObj.room= visitor.uniqueKey;
      this.SocketioService.emitVisitor(this.claimObj);
      window.location.reload();
    
   
    }
    getCurrentVisitor(visitor){
      this.CurrentVisitorId = visitor.id;
      this.CurrentVisitorName = visitor.visitorName;
      this.CurrentVisitorIP = visitor.ipAdd;
      this.CurrentVisitorLocation = visitor.chatsResult;
      this.CurrentVisitorBrowser = visitor.browser;
      this.CurrentVisitorPCtype = visitor.deviceType;
      this.CurrentVisitorAdded = visitor.visitedOn;
      this.CurrentVisitorOs = visitor.osType;
      this.CurrentVisitorKey = visitor.uniqueKey;
    
      this.roomObj = {
        roomId: visitor.uniqueKey,
        userId:  this.userData.userId
    }
      this.SocketioService.emitClaimedVisitor(this.roomObj);
      this.startChat=true;  
       //this.allMsgs=[];
      
    }
 editdetail(visitor: any){
  visitor.editable = !visitor.editable;  
 }

sendMsg1(){
   
  if(!isNullOrUndefined(this.sendMsg) && this.sendMsg != ''){
    //this.sendMsgs.push(this.sendMsg);
  this.msgSend=true; 
  this.message.msg= this.sendMsg;
  this.message.type= 'server';
  this.message.room= this.CurrentVisitorKey, //umiqu key
  this.message.senderId= this.userData.userId, //agentId
  this.message.reciverId= this.CurrentVisitorId, //currentvisitor Id
  this.message.username=this.userData.user;//AgentName
 
  this.SocketioService.sendChatMsg(this.message);
  console.log('sendMsg1');
  console.log(this.message);
  this.message={};
  this.sendMsg='';
 
 
  }


 
}
toggleDiv(){
  this.isShowDiv =!this.isShowDiv;
}
toggleDiv1(){
  this.isShowDiv1 =!this.isShowDiv1;
}
  }


