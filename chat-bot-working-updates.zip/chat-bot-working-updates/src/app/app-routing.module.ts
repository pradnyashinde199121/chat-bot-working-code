import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ThemeComponent } from './theme/theme.component';
import { LoginComponent } from './login/login.component';
import { RegistorComponent } from './registor/registor.component';
const routes: Routes = [
  { path: 'theme', component: ThemeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'registor', component: RegistorComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
