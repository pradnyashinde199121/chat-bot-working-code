import { Injectable } from '@angular/core';
import * as io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class SocketioService {
  message: any =[];
  socket = io(environment.SOCKET_ENDPOINT);
  constructor() {   }
  private chatMsg = new BehaviorSubject(null);
  chatMsgs = this.chatMsg.asObservable();

  private historyMsg = new BehaviorSubject(null);
  historyMsgs = this.historyMsg.asObservable();
  private sendClaimedUser = new BehaviorSubject(null);
  sendClaimedUsers = this.sendClaimedUser.asObservable();
  setupSocketConnection() {   
   
      this.socket.on('testM', (data: any) => {
        this.updateCHatMsg(data);
        console.log(data);
      });      
    
  }
  updateCHatMsg(msg :any){
    this.chatMsg.next(msg);
  }
  updateHistoryMsg(msg :any){
    this.historyMsg.next(msg);
  }
  sendChatMsg(msg :any){
    this.socket.emit('testMessage', msg);         
  }
  emitVisitor(res:any) {
    this.socket.emit('claimvisitor', res);  
}
getVisitorHistory(){
  this.socket.on('getchat', (result:any,status:any,visitorsResult:any)=>{
    this.updateHistoryMsg(result);
    // console.log(result);
    // console.log(status);
    console.log("status");
    console.log(visitorsResult );
  })
}

emitClaimedVisitor(roomObj) {
  this.socket.emit('joinVisitor',{roomId : roomObj.roomId});
  this.socket.emit('chathistory',roomObj,() => {
    console.log('get chat history');
})
}


}