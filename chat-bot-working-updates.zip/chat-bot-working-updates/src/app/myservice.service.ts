import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  url='assets/users.json';
  urlvisitor='assets/visitors-info.json';
  email:any=localStorage.getItem('email');

  constructor(private http: HttpClient) { }
  getUser():Observable<any>{
    return this.http.get<any>(this.url);
  }
  // getVisitor():Observable<any>{
  //   // return this.http.get<any>(this.urlvisitor);
  //   return this.http.get<any>('http://localhost:3000/chatbotTheme');
  // }
  Login(loginData):Observable<any> {
    return this.http.post<any>('http://localhost:3000/login', loginData);
   
}
Register(registerData):Observable<any> {
  return this.http.post<any>('http://localhost:3000/register', registerData);
}
getUsers():Observable<any> {
  return this.http.get<any>('http://localhost:3000/chatbotTheme/?q='+ this.email);
}

  
}
